package kodlamaio.northwind.dataAccess.abstracts;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import kodlamaio.northwind.entities.concretes.Product;
import kodlamaio.northwind.entities.dtos.ProductWithCategoryDto;

import java.util.List;


public interface ProductDao extends JpaRepository<Product, Integer> {
	
	// Ürün ismine göre (productName) bir ürün getirir.
	Product getByProductName(String productName);
	
	// Hem ürün ismine hem de kategori kimliğine göre bir ürün getirir.
	Product getByProductNameAndCategory_CategoryId(String productName, int categoryId);
	
	// Ürün ismine veya kategori kimliğine göre ürünleri getirir.
	List<Product> getByProductNameOrCategory_CategoryId(String productName, int categoryId);
	
	// Verilen kategori kimlikleri listesi içerisindeki ürünleri getirir.
	List<Product> getByCategoryIn(List<Integer> categories);
	
	// Ürün isminde verilen string'i içeren ürünleri getirir.
	List<Product> getByProductNameContains(String productName);
	
	// Ürün ismi verilen string ile başlayan ürünleri getirir.
	List<Product> getByProductNameStartsWith(String productName);
	
	@Query("From Product where productName=:productName and category.categoryId=:categoryId")
	List<Product> getByNameAndCategory(String productName, int categoryId);
	
	@Query("Select new kodlamaio.northwind.entities.dtos.ProductWithCategoryDto" + "(p.id, p.productName, c.categoryName) " + "From Category c Inner Join c.products p")
	List<ProductWithCategoryDto> getProductWithCategoryDetails();

	
}








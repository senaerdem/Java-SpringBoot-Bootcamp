package kodlamaio.northwind.entities.dtos;

public class ProductWithCategoryDto {
	private int id;
	private String productNameString;
	private String categoryName;
	
	ProductWithCategoryDto() {
		
	}
	
	public ProductWithCategoryDto(int id, String productNameString, String categoryName) {
		super();
		this.id = id;
		this.productNameString = productNameString;
		this.categoryName = categoryName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductNameString() {
		return productNameString;
	}

	public void setProductNameString(String productNameString) {
		this.productNameString = productNameString;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
}

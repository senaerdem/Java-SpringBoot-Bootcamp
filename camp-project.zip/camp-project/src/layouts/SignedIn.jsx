import React from 'react'
import { Dropdown, DropdownMenu, Menu, Image } from 'semantic-ui-react'

export default function SignedIn({signOut}) {
  return (
    <div>
        <Menu.Item>
            <Image avatar spaced="right" src="https://avatars.githubusercontent.com/u/98752496?v=4" />
            <Dropdown pointing="top left" text="Sena">
                <DropdownMenu>
                    <Dropdown.Item text="Info" icon="info"/>
                    <Dropdown.Item onClick={signOut} text="Log Out" icon="sign-out"/>
                </DropdownMenu>
            </Dropdown>
        </Menu.Item>
    </div>
  )
}

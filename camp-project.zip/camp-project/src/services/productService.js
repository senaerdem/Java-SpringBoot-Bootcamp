import axios from "axios"

export default class ProductService {
    getProducts(){
        return axios.get("http://localhost:8080/api/products/getall") // service'e request atar
    }
    getByProductName(productName){
        return axios.get("http://localhost:8080/api/products/getByProductName?productName="+productName)
    }
    deleteProduct(productId) {
         return axios.delete(`http://localhost:8080/api/products/delete?productId=${productId}`);
    }
}
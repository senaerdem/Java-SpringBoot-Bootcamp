import React from 'react'

export default function CartDetail() {
  return (
    <div>Cart Detail</div>
  )
}

import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import {
  CardMeta,
  CardHeader,
  CardGroup,
  CardDescription,
  CardContent,
  Button,
  Card,
  Image,
} from 'semantic-ui-react'
import ProductService from '../services/productService';

export default function ProductDetail() {
  let {name} = useParams()

  const [product, setProduct] = useState({});

  useEffect(()=>{
    let productService = new ProductService()
    productService.getByProductName(name).then(result=>setProduct(result.data.data))
  }, [])

  return (
    <div>
      <Card.Group>
    <Card fluid>
      <CardContent>
        <CardHeader>{product.productName}</CardHeader>
        <CardMeta>{product.unitPrice}</CardMeta>
        <CardDescription>
          {product.quantityPerUnit}
        </CardDescription>
      </CardContent>
      <CardContent extra>
        <div className='ui two buttons'>
          <Button basic color='green'>
            Add to Cart
          </Button>
          <Button basic color='red'>
            Add to Favorite
          </Button>
        </div>
      </CardContent>
    </Card>
  </Card.Group>
    </div>
  )
}

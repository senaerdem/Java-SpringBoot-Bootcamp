import React from 'react'
import { Formik, Form } from 'formik'
import * as Yup from "yup";
import { Button} from 'semantic-ui-react';
import KodlamaIoTextInput from '../utilities/customFormControls/KodlamaIoTextInput';

export default function ProductAdd() {

  const initialValues = {productName:"", unitPrice:10}

  const schema = Yup.object({
    productName: Yup.string().required("Product name is required!"),
    unitPrice: Yup.number().required("Unit price is required!")
  });

  return (
    <div>
        <Formik
        initialValues={initialValues}
        validationSchema={schema}
        onSubmit={(values)=> {
            console.log(values)
        }}
        >
            <Form className="ui form">
                <KodlamaIoTextInput name="productName" placeholder="Product Name"/>
                <KodlamaIoTextInput name="unitPrice" placeholder="Price"/>
                {/* <FormField>
                    <Field name="productName" placeholder="Product Name"></Field>
                    <ErrorMessage name="productName" render={error=>
                        <Label pointing basic color="red" content={error}></Label>
                    }></ErrorMessage>
                </FormField> */}
                {/* <FormField>
                    <Field name="unitPrice" placeholder="Price"></Field>
                    <ErrorMessage name="unitPrice" render={error=>
                        <Label pointing basic color="red" content={error}></Label>
                    }></ErrorMessage>
                </FormField> */}
                <Button color="green" type="submit">Add</Button>
            </Form> 
        </Formik>
    </div>
  )
}
